import { saveGame } from "./gameState";

export function initBackgroundSaves() {
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
      // Tab is weg → meteen opslaan
      saveGame();
    } else {
      // Tab terug → ook opslaan voor veiligheid
      saveGame();
    }
  });
}
