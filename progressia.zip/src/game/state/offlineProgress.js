import { getGame, addItem, addXp, saveGame } from "./gameState";

export function handleOfflineProgress() {
  const game = getGame();

  const now = Date.now();
  const last = Number(localStorage.getItem("lastOnline")) || now;

  const elapsed = now - last; // ms
  const seconds = Math.floor(elapsed / 1000);

  if (seconds <= 0) {
    localStorage.setItem("lastOnline", now);
    saveGame();
    return [];
  }

  const summary = [];

  for (const key in game.skills) {
    const skill = game.skills[key];

    // Niet actief voor offline progress?
    if (!skill.wasActive) continue;

    // NEW SYSTEM — skill.currentAction
    if (skill.currentAction) {
      const action = skill.currentAction;
      const cycles = Math.floor(elapsed / action.actionTime);

      if (cycles > 0) {
        const gained = cycles * action.amountGain;
        addItem(action.resource, gained);
        addXp(key, cycles * action.xpGain);

        summary.push({
          skill: skill.name,
          gained,
          resource: action.resource,
        });
      }
    }

    // OLD SYSTEM — fallback
    else if (skill.isIdle && skill.resource) {
      const cycles = Math.floor(elapsed / skill.actionTime);

      if (cycles > 0) {
        const gained = cycles * skill.amountGain;
        addItem(skill.resource, gained);
        addXp(key, cycles * skill.xpGain);

        summary.push({
          skill: skill.name,
          gained,
          resource: skill.resource,
        });
      }
    }
  }

  localStorage.setItem("lastOnline", now);
  saveGame();

  return summary;
}

export function testOfflineProgress(minutes = 60) {
  const fakePast = Date.now() - minutes * 60 * 1000;
  localStorage.setItem("lastOnline", fakePast);

  return handleOfflineProgress();
}
