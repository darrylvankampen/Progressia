import { reactive } from "vue";
import { defaultGame } from "../defaultGame";
import { playSound } from "../soundManager";
import { initItems, getItem } from "../utils/itemDB";
import { loadAllSkills } from "../skills/skillLoader";
import { useNotifications } from "../../composables/useNotification";
const { pushNotification } = useNotifications();

// -------------------------------------------------------
// INTERNE STATE
// -------------------------------------------------------

let game = reactive(structuredClone(defaultGame));
let skillDefs = null; // dynamische skill-definities (inline SVG etc.)
let skillDefsReadyResolve;
let gameReadyResolve;
export const gameReady = new Promise((resolve) => {
  gameReadyResolve = resolve;
});
export const skillDefsReady = new Promise((r) => (skillDefsReadyResolve = r));

// Items één keer initialiseren (zit NIET in game-state)
initItems();

// Start async load van save + skills

(async () => {
  await ensureSkillsLoaded();
  await initGame();
})();

// -------------------------------------------------------
// INIT FLOW
// -------------------------------------------------------

async function initGame() {
  try {
    const loaded = await loadGameFromStorage();
    Object.assign(game, loaded);
    game.player = loaded.player;
  } catch (err) {
    console.error("[Progressia] Failed to load game, using defaults:", err);
  } finally {
    if (gameReadyResolve) gameReadyResolve();
  }
}

async function ensureSkillsLoaded() {
  if (!skillDefs) {
    skillDefs = await loadAllSkills();
    skillDefsReadyResolve(); // mark ready
  }
}

function extractSkillProgress(savedSkill) {
  if (!savedSkill) {
    return {
      level: 1,
      xp: 0,
      xpToNext: 50,
      currentActionId: null,
      timeLeft: 0,
      isActive: false,
      wasActive: false,
    };
  }

  return {
    level: savedSkill.level ?? 1,
    xp: savedSkill.xp ?? 0,
    xpToNext: savedSkill.xpToNext ?? 50,
    currentActionId: savedSkill.currentActionId ?? null,
    timeLeft: savedSkill.timeLeft ?? 0,
    isActive: false, // altijd reset naar false bij load
    wasActive: savedSkill.wasActive ?? false,
  };
}
// -------------------------------------------------------
// PUBLIC API
// -------------------------------------------------------

export function getGame() {
  return game;
}

export async function resetGame() {
  await ensureSkillsLoaded();

  const fresh = structuredClone(defaultGame);

  // Skills opnieuw opbouwen (config + default progress)
  fresh.skills = {};

  for (const id in skillDefs) {
    const def = skillDefs[id];

    fresh.skills[id] = {
      ...structuredClone(def), // skill config
      level: 1,
      xp: 0,
      xpToNext: 50,
      currentActionId: null,
      currentAction: null,
      timeLeft: 0,
      isActive: false,
      wasActive: false,
    };
  }

  // Inventory legen
  fresh.inventory = {};

  // Active skill resetten
  fresh.activeSkill = null;

  // State vervangen
  Object.assign(game, fresh);

  saveGame();
}

export function saveGame() {
  const saveReady = {
    player: {
      name: game.player.name,
      gold: game.player.gold,
      hp: game.player.hp,
      maxHp: game.player.maxHp,
      totalXP: game.player.totalXP,
      equippedTools: { ...game.player.equippedTools },
    },
    inventory: { ...game.inventory },
    skills: {},
    activeSkill: game.activeSkill,
  };

  for (const id in game.skills) {
    const s = game.skills[id];

    saveReady.skills[id] = {
      level: s.level,
      xp: s.xp,
      xpToNext: s.xpToNext,
      currentActionId: s.currentActionId || null,
      timeLeft: s.timeLeft || 0,
      isActive: s.isActive || false,
      wasActive: s.wasActive || false,
    };
  }

  try {
    localStorage.setItem("progressia-save", JSON.stringify(saveReady));
  } catch (err) {
    console.error("[Progressia] Failed to save game:", err);
  }
}

// -------------------------------------------------------
// XP SYSTEM
// -------------------------------------------------------

export function addXp(skillKey, amount) {
  const skill = game.skills[skillKey];
  if (!skill || amount <= 0) return;

  skill.xp += amount;
  game.player.totalXP += amount;
  let leveled = false;

  while (skill.xp >= skill.xpToNext && skill.level < skill.maxLevel) {
  skill.xp -= skill.xpToNext;
  skill.level++;

  if (skill.level < skill.maxLevel) {
    skill.xpToNext = Math.floor(50 * Math.pow(skill.level, 1.8));
  } else {
    skill.xpToNext = 0;
    skill.xp = Math.min(skill.xp, skill.xpToNext);
  }

  leveled = true;
}

  if (leveled) {
    skill.justLeveled = true;
    playSound("levelup");

    setTimeout(() => {
      skill.justLeveled = false;
    }, 1500);
  }

  saveGame();
}

// -------------------------------------------------------
// ITEM SYSTEM
// -------------------------------------------------------

export function addItem(itemKey, amount = 1) {
  const item = getItem(itemKey);

  if (!item) {
    console.warn("[Progressia] Unknown item:", itemKey);
    return;
  }

  if (!game.inventory[itemKey]) {
    game.inventory[itemKey] = 0;
  }

  game.inventory[itemKey] += amount;

  pushNotification(item.name, `+${amount} ${item.name}`);

  console.log(`[Progressia] Added ${amount}x ${item.name}`);
  saveGame();
}

export function removeItem(itemKey, amount = 1) {
  console.log("[removeItem] Called with:", itemKey, "amount:", amount);
  console.log("[removeItem] BEFORE:", game.inventory[itemKey]);

  if (!game.inventory[itemKey]) {
    console.warn("[removeItem] Item not found in inventory:", itemKey);
    return;
  }

  game.inventory[itemKey] -= amount;
  console.log("[removeItem] AFTER:", game.inventory[itemKey]);

  if (game.inventory[itemKey] <= 0) {
    console.log("[removeItem] Removing item entirely:", itemKey);
    delete game.inventory[itemKey];
  }

  saveGame();
}

// -------------------------------------------------------
// LOAD SYSTEM
// -------------------------------------------------------

async function loadGameFromStorage() {
  const raw = localStorage.getItem("progressia-save");
  let base;

  if (!raw) {
    base = structuredClone(defaultGame);
  } else {
    try {
      const parsed = JSON.parse(raw);
      base = mergeSave(parsed, defaultGame);
    } catch (err) {
      console.warn("[Progressia] Corrupted save, using defaults:", err);
      base = structuredClone(defaultGame);
    }
  }

  // Zorg dat inventory altijd bestaat
  if (!base.inventory) base.inventory = {};

  // Onbekende items uit saves verwijderen
  for (const key of Object.keys(base.inventory)) {
    if (!getItem(key)) {
      console.warn(
        "[Progressia] Removing unknown inventory item from save:",
        key
      );
      delete base.inventory[key];
    }
  }

  // Skills dynamisch mergen
  await ensureSkillsLoaded();
  if (!base.player.equippedTools) {
    base.player.equippedTools = {};
  }
  if (!base.skills) base.skills = {};

  for (const id in skillDefs) {
    const def = skillDefs[id];
    const existing = base.skills[id];

    const progress = extractSkillProgress(existing);

    base.skills[id] = {
      ...structuredClone(def), // ALTIJD externe config
      ...progress, // ALLEEN progress uit save
    };
  }

  return base;
}

export function equipTool(skillId, toolId) {
  const game = getGame();

  // Bestaat tool?
  const tool = getItem(toolId);
  if (!tool) {
    console.warn(`[equipTool] Tool '${toolId}' not found.`);
    return false;
  }

  // Is het item wel een tool?
  if (tool.category !== "tools") {
    console.warn(`[equipTool] Item '${toolId}' is not a tool.`);
    return false;
  }

  // Is de tool gekoppeld aan de juiste skill?
  if (tool.skill !== skillId) {
    console.warn(
      `[equipTool] Tool '${toolId}' does not belong to skill '${skillId}'.`
    );
    return false;
  }

  // equippedTools initialiseren indien nodig
  if (!game.player.equippedTools) {
    game.player.equippedTools = {};
  }

  // Heeft speler voldoende level voor deze tool?
  const skill = game.skills[skillId];
  if (skill.level < tool.stats.requiredLevel) {
    console.warn(
      `[equipTool] Player level too low for ${toolId}. ` +
        `Required: ${tool.stats.requiredLevel}, ` +
        `Current: ${skill.level}`
    );
    return false;
  }

  // Tool equippen
  game.player.equippedTools[skillId] = toolId;

  console.log(`[equipTool] Equipped ${toolId} for ${skillId}`);

  saveGame();
  return true;
}

// -------------------------------------------------------
// MERGE SYSTEM (safe loading + migrations)
// -------------------------------------------------------

function isPlainObject(val) {
  return val && typeof val === "object" && !Array.isArray(val);
}

/**
 * Merge opgeslagen save in het huidige template (defaultGame),
 * met speciale regels voor dynamische delen zoals inventory & skills.
 */
function mergeSave(save, template) {
  const result = structuredClone(template);

  for (const key in template) {
    if (!(key in save)) continue;

    if (key === "player") {
      result.player = {
        ...template.player,
        ...save.player,
      };
      continue;
    }

    // Inventory: volledig uit save overnemen (dynamische keys)
    if (key === "inventory") {
      result.inventory = save.inventory || {};
      continue;
    }

    // Skills: dynamisch, worden later apart gemerged via skillDefs
    if (key === "skills") {
      result.skills = save.skills || {};
      continue;
    }

    const tplVal = template[key];
    const saveVal = save[key];

    if (isPlainObject(tplVal) && isPlainObject(saveVal)) {
      result[key] = mergeSave(saveVal, tplVal);
    } else {
      result[key] = saveVal;
    }
  }

  return result;
}

export function getSkillDefs() {
  return skillDefs;
}
