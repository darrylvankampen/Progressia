import { loadAllItems } from "./itemLoader";

let itemDB = {};

export function initItems() {
  itemDB = loadAllItems();
  console.log(itemDB)
}

export function getItem(key) {
  return itemDB[key];
}

export function getAllItems() {
  return itemDB;
}
