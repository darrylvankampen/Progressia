export const defaultGame = {
  player: {
    name: "Hero",
    gold: 0,
    hp: 100,
    maxHp: 100,
    totalXP: 0,
    equippedTools: {},
  },
  skills: {},
  inventory: {},
  craftingQueue: [],
  craftingTimeRemaining: 0,
  activeSkill: null,
};
