// src/game/skillEngine.js

import {
  addItem,
  addXp,
  getGame,
  saveGame,
  gameReady,
} from "./state/gameState";
import { getToolStats } from "./helpers/gameHelpers";

// Hoe vaak het spel tikt (in ms)
const TICK_MS = 100;

// -------------------------------------------------------------
// HELPER: reconstruct currentAction uit config + progress
// -------------------------------------------------------------
function rebuildCurrentAction(skill) {
  if (!skill.currentActionId) return null;
  if (!Array.isArray(skill.actions)) return null;

  const base = skill.actions.find((a) => a.id === skill.currentActionId);
  if (!base) {
    console.warn("[Progressia] Action not found:", skill.currentActionId);
    skill.currentAction = null;
    return null;
  }

  // 🔥 TOOL STATS OPNIEUW BEREKENEN
  const tool = getToolStats(skill.id || skill.key || skill.name || "woodcutting");

  const effectiveTime = Math.max(
    200,
    Math.floor(base.actionTime / (tool.speedMultiplier || 1))
  );

  const effectiveXp = Math.floor(base.xpGain * (tool.xpMultiplier || 1));

  const timeLeft =
    typeof skill.timeLeft === "number" && skill.timeLeft > 0
      ? skill.timeLeft
      : effectiveTime;

  const currentAction = {
    ...base,
    actionTime: effectiveTime,
    xpGain: effectiveXp,
    doubleChance: tool.doubleChance || 0,
    timeLeft,
  };

  skill.currentAction = currentAction;
  skill.timeLeft = timeLeft;

  return currentAction;
}


// -------------------------------------------------------------
// GLOBAL TICK LOOP
// -------------------------------------------------------------
// Elke 100ms loopt het spel één "tick".
// Hiermee kunnen we timeLeft real-time aftellen voor progressbars.
// -------------------------------------------------------------
function gameTick() {
  const game = getGame();

  for (const key in game.skills) {
    const skill = game.skills[key];

    // ---------------------------
    // NIEUW: Slechts 1 skill tegelijk
    // ---------------------------
    if (game.activeSkill && game.activeSkill !== key) {
      // Stop deze skill direct als hij niet de actieve is
      skill.isActive = false;
      skill.currentActionId = null;
      skill.currentAction = null;
      skill.timeLeft = 0;
      continue;
    }

    // Als deze skill niet actief is, skippen
    if (!skill || !skill.isActive || !skill.currentActionId) continue;

    // Zorg dat currentAction bestaat (na refresh wordt deze herbouwd)
    let action = skill.currentAction;
    if (!action) {
      action = rebuildCurrentAction(skill);
      if (!action) {
        // Kan de actie niet reconstrueren → stop de skill
        skill.isActive = false;
        continue;
      }
    }

    // Zorg dat timeLeft een geldig nummer is
    if (typeof skill.timeLeft !== "number" || skill.timeLeft <= 0) {
      skill.timeLeft = action.actionTime ?? TICK_MS;
    }

    // 100ms per tick omlaag tellen
    skill.timeLeft -= TICK_MS;
    action.timeLeft = skill.timeLeft;

    // Actie klaar?
    if (skill.timeLeft <= 0) {
      // Run actie
      performSkillAction(key, action);

      // Reset timer voor volgende cycle
      skill.timeLeft = action.actionTime ?? TICK_MS;
      action.timeLeft = skill.timeLeft;

      saveGame();
    }
  }
}

// Start de globale tick-loop
setInterval(gameTick, TICK_MS);

// -------------------------------------------------------------
// START EEN SPECIFIEKE ACTION
// -------------------------------------------------------------
// Wordt aangeroepen vanuit de SkillPage:
// startAction("woodcutting", action)
// waarbij `action` uit skill.actions komt (config)
// -------------------------------------------------------------
export function startAction(skillKey, action) {
  const game = getGame();

  stopAllSkills(skillKey);

  const skill = game.skills[skillKey];
  if (!skill || !action) return;

  skill.currentActionId = action.id;

  // TOOL DATA
  const tool = getToolStats(skillKey);

  // ⚡ Correcte snelheid: Delen ipv vermenigvuldigen
  const effectiveTime = Math.max(
    200,
    Math.floor(action.actionTime / (tool.speedMultiplier || 1))
  );

  const effectiveXp = Math.floor(action.xpGain * (tool.xpMultiplier || 1));

  skill.currentAction = {
    ...action,
    actionTime: effectiveTime,
    xpGain: effectiveXp,
    doubleChance: tool.doubleChance || 0,
    timeLeft: effectiveTime,
  };

  skill.timeLeft = effectiveTime;
  skill.isActive = true;
  skill.wasActive = true;

  game.activeSkill = skillKey;

  saveGame();
}


// -------------------------------------------------------------
// STOP DE SKILL
// -------------------------------------------------------------
export function stopSkill(skillKey) {
  const game = getGame();
  const skill = game.skills[skillKey];

  if (!skill) return;

  skill.isActive = false;
  skill.wasActive = false;
  skill.currentActionId = null;
  skill.currentAction = null;
  skill.timeLeft = 0;

  if (game.activeSkill === skillKey) {
    game.activeSkill = null;
  }

  saveGame();
}

// -------------------------------------------------------------
// PERFORM ACTION (wordt elke keer uitgevoerd als timeLeft <= 0)
// -------------------------------------------------------------
export function performSkillAction(skillKey, actionOverride) {
  const game = getGame();
  const skill = game.skills[skillKey];
  const action = actionOverride || skill?.currentAction;

  if (!skill || !action) return;

  // TOOL: double chance
  let gain = action.amountGain;
  if (action.doubleChance && Math.random() < action.doubleChance) {
    gain *= 2;
    console.log(`[Tool] DOUBLE yield on ${action.id}`);
  }

  // Basis reward
  if (action.resource && gain > 0) {
    addItem(action.resource, gain);
  }

  // XP (tool multiplier was al toegepast bij startAction)
  if (action.xpGain > 0) {
    addXp(skillKey, action.xpGain);
  }

  // Rare drops (blijft hetzelfde)
  if (Array.isArray(action.rareDrops)) {
    for (const drop of action.rareDrops) {
      if (!drop.item || typeof drop.chance !== "number") continue;
      if (Math.random() < drop.chance) {
        addItem(drop.item, 1);
        console.log(`[RareDrop] ${drop.item} from ${action.id}`);
      }
    }
  }
}

// -------------------------------------------------------------
// RESUME NA REFRESH
// -------------------------------------------------------------
// Zorgt ervoor dat skills verdergaan als het spel herladen wordt
// -------------------------------------------------------------
export function resumeSkill(skillKey) {
  const game = getGame();
  const skill = game.skills[skillKey];

  if (!skill) return;

  // Niet de globale active skill? -> skip
  if (game.activeSkill && game.activeSkill !== skillKey) {
    skill.isActive = false;
    skill.wasActive = false;
    skill.currentActionId = null;
    skill.currentAction = null;
    skill.timeLeft = 0;
    return;
  }

  if (!skill.wasActive || !skill.currentActionId) return;

  const action = rebuildCurrentAction(skill);
  if (!action) {
    stopSkill(skillKey);
    return;
  }

  skill.isActive = true;
}
// -------------------------------------------------------------
// RESUME ALLE SKILLS
// -------------------------------------------------------------
export function resumeAllActiveSkills() {
  const game = getGame();

  for (const key in game.skills) {
    resumeSkill(key);
  }
}

function stopAllSkills(except = null) {
  const game = getGame();

  for (const key in game.skills) {
    if (key === except) continue;

    const skill = game.skills[key];
    skill.isActive = false;
    skill.wasActive = false;
    skill.currentActionId = null;
    skill.currentAction = null;
    skill.timeLeft = 0;
  }
}

// -------------------------------------------------------------
// KOPPELING MET gameReady
// -------------------------------------------------------------
// Zodra de game + skillDefs geladen zijn, acties hervatten
// -------------------------------------------------------------
gameReady.then(() => {
  resumeAllActiveSkills();
});
