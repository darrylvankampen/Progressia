<template>
  <div class="app-layout">
    <!-- TOP BAR (fixed) -->
    <TopBar />
    <Notification />
    <ItemTooltip />
    <ItemActionsMenu />

    <!-- SIDEBAR (fixed left) -->
    <Sidebar :items="tabs" v-model="activeTab" />

    <!-- MAIN CONTENT -->
    <div class="content">
      <OfflinePopup ref="offlinePopup" />
      <!-- NORMAL TABS MODE -->
      <router-view />
    </div>
  </div>
</template>

<script setup>
/* EXACT zoals jij het had — NIETS aangepast */
import { computed, ref, onMounted } from "vue";

import Sidebar from "./components/Sidebar.vue";

import OfflinePopup from "./components/OfflinePopup.vue";
import { startAutosave } from "./game/state/autosave";
import { initBackgroundSaves } from "./game/state/backgroundsaves";
import {
  testOfflineProgress,
  handleOfflineProgress,
} from "./game/state/offlineProgress";

const activeTab = ref("player");

import { gameReady } from "./game/state/gameState";
import { resumeAllActiveSkills } from "./game/skillEngine";
import TopBar from "./components/TopBar.vue";
import Notification from "./components/Notification.vue";
import ItemTooltip from "./components/ItemTooltip.vue";
import ItemActionsMenu from "./components/ItemActionsMenu.vue";
const offlinePopup = ref(null);

const tabs = [
  { id: "player", label: "Player", icon: "🧍", to: "/player" },
  { id: "skills", label: "Skills", icon: "⚒️", to: "/skills" },
  { id: "crafting", label: "Crafting", icon: "🛠️", to: "/skills/crafting" },
  { id: "inventory", label: "Inventory", icon: "🎒", to: "/inventory" },
  { id: "shop", label: "Shop", icon: "🛒", to: "/shop" },
  { id: "settings", label: "Settings", icon: "⚙️", to: "/settings" },
];

onMounted(async () => {
  await gameReady;
  const summary = handleOfflineProgress();
  if (summary && summary.length > 0 && offlinePopup.value) {
    offlinePopup.value.show(summary);
  }

  resumeAllActiveSkills();
  startAutosave(5000);
  initBackgroundSaves();
});
</script>

<style>
.app-layout {
  display: flex;
}

/* TOP BAR ruimte vrijhouden boven content */
.content {
  position: relative;
  margin-top: 52px; /* hoogte topbar */
  margin-left: var(--sidebar-width);
  padding: 20px;
  width: calc(100% - var(--sidebar-width));
  transition: margin-left 0.3s ease, width 0.3s ease;
}

/* Dynamische CSS variabelen — sidebar stuurt dit aan */
:root {
  --sidebar-width: 240px;
}

.sidebar-collapsed + .content {
  --sidebar-width: 80px !important;
}
</style>
