import { ref } from "vue";

const actionState = ref({
  visible: false,
  item: null,
  x: 0,
  y: 0,
});

export function useItemActions() {
  function showActions(item, event) {
    actionState.value = {
      visible: true,
      item,
      x: event.clientX + 10,
      y: event.clientY + 10,
    };
  }

  function hideActions() {
    actionState.value.visible = false;
  }

  return { actionState, showActions, hideActions };
}
