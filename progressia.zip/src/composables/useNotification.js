import { ref } from "vue";

const notifications = ref([]);

export function useNotifications() {
  function pushNotification(key, message, duration = 2000) {
    // Check of er al een notificatie met dezelfde key is
    const existing = notifications.value.find(n => n.key === key);

    if (existing) {
      // Voeg 1 toe aan het aantal
      existing.count++;
      existing.message = `${message} ×${existing.count}`;

      // Reset timer (zodat hij niet te snel verdwijnt)
      clearTimeout(existing.timeout);
      existing.timeout = setTimeout(() => {
        removeNotification(existing.id);
      }, duration);

      return;
    }

    // Nieuwe notificatie
    const id = Date.now() + Math.random();

    const timeout = setTimeout(() => {
      removeNotification(id);
    }, duration);

    notifications.value.push({
      id,
      key,      // KEY bepaalt of hij stackt
      message,
      count: 1,
      timeout
    });
  }

  function removeNotification(id) {
    notifications.value = notifications.value.filter(n => n.id !== id);
  }

  return { notifications, pushNotification };
}
