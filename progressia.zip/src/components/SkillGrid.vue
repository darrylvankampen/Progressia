<template>
  <div class="row g-4">
    <div
      v-for="skill in skills"
      :key="skill.key"
      class="col-12 col-md-4"
    >
      <SkillCard
        :skill="skill"
        :skillKey="skill.key"
        :inventory="inventory"
        @click="$emit('open-skill', skill.key)"
      />
    </div>
  </div>
</template>


<script setup>
import SkillCard from "./SkillCard.vue";

const props = defineProps({
  skills: Array,      // <-- gewijzigd naar Array
  inventory: Object
});

const emit = defineEmits(["open-skill", "open-crafting"]);

function goToCrafting() {
  // scroll naar crafting sectie
  emit("open-crafting");
}
</script>
