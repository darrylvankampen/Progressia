<template>
  <div v-if="visible" class="offline-overlay" @click.self="close">
    <div class="offline-popup shadow-lg">
      <h2 class="title">⏳ Offline Progress</h2>

      <div class="summary-list">
        <div
          v-for="entry in summary"
          :key="entry.skill"
          class="summary-row"
        >
          <strong>{{ entry.skill }}</strong>
          <span class="reward">
            +{{ entry.gained }} {{ entry.resource }}
          </span>
        </div>
      </div>

      <button class="btn btn-primary w-100 mt-3" @click="close">
        Okay
      </button>
    </div>
  </div>
</template>

<script setup>
import { ref } from "vue";

const visible = ref(false);
const summary = ref([]);

function show(data) {
  summary.value = data;
  visible.value = true;
}

function close() {
  visible.value = false;
}

// Expose for parent
defineExpose({ show });
</script>

<style scoped>
/* Dark fantasy overlay */
.offline-overlay {
  position: fixed;
  inset: 0;
  background: rgba(15, 5, 2, 0.75);
  backdrop-filter: blur(4px);
  display: flex;
  justify-content: center;
  align-items: center;
  animation: fadeIn 0.4s ease forwards;
  z-index: 9999;
}

/* Popup box */
.offline-popup {
  background: rgba(40, 28, 18, 0.92);
  border: 3px solid #a67c52;
  padding: 25px;
  width: 350px;
  max-width: 90%;
  border-radius: 12px;
  animation: popIn 0.35s ease;
  color: #fbeec1;
  font-family: "Cinzel", serif;
}

.title {
  font-size: 1.6rem;
  text-align: center;
  margin-bottom: 15px;
  text-shadow: 0 0 8px rgba(255, 230, 180, 0.7);
}

/* List */
.summary-list {
  max-height: 200px;
  overflow-y: auto;
  padding-right: 6px;
}

.summary-row {
  display: flex;
  justify-content: space-between;
  padding: 6px 0;
  border-bottom: 1px solid rgba(255, 235, 200, 0.18);
}

.reward {
  color: #ffdf8b;
  font-weight: bold;
}

/* Animations */
@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

@keyframes popIn {
  0% { opacity: 0; transform: scale(0.7); }
  100% { opacity: 1; transform: scale(1); }
}
</style>
