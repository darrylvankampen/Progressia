<template>
  <div
    class="inventory-item"
    :class="{ locked: isLocked, equipped: isEquipped }"
    :style="{ '--rarity-color': rarityColor }"
    @mouseenter="showTooltip(item, $event)"
    @mouseleave="hideTooltip()"
    @mousemove="showTooltip(item, $event)"
    @click="showActions(item, $event)"
  >
    <div class="icon-wrapper">
      <img class="inventory-icon" :src="item.icon" />
    </div>

    <div class="inventory-info">
      <!-- TITEL + BADGES -->
      <div class="name-row">
        <span class="inventory-name">{{ item.name }} ({{ item.amount }}x)</span>

        <!-- BADGES RECHTS -->
        <span v-if="isEquipped" class="badge equipped-badge">Equipped</span>
        <span v-if="isLocked" class="badge locked-badge">
          Lvl {{ props.item.stats.requiredLevel }}
        </span>
      </div>

      <!-- RARITY -->
      <span class="rarity-tag">
        {{ rarityLabel }}
      </span>
    </div>
  </div>
</template>

<script setup>
import { computed } from "vue";
import { getRarityColor, getRarityLabel } from "../game/utils/rarity";
import { useTooltip } from "../composables/useTooltip";
const { showTooltip, hideTooltip } = useTooltip();
import { useItemActions } from "../composables/useItemActions";
import { getGame } from "../game/state/gameState";
const { showActions } = useItemActions();

const game = getGame();

const isTool = computed(() => props.item.category === "tools");
const skillId = computed(() => props.item.skill || null);

const playerSkill = computed(() => {
  if (!skillId.value) return null;
  return game.skills[skillId.value];
});

// Equipped?
const isEquipped = computed(() => {
  if (!isTool.value) return false;
  return game.player.equippedTools?.[skillId.value] === props.item.id;
});

// Locked? (requiredLevel)
const isLocked = computed(() => {
  if (!isTool.value) return false;
  const req = props.item.stats?.requiredLevel ?? 1;
  return playerSkill.value?.level < req;
});

const props = defineProps({
  item: Object,
});

const rarityColor = computed(() => getRarityColor(props.item.rarity));
const rarityLabel = computed(() => getRarityLabel(props.item.rarity));
</script>

<style scoped>
.inventory-item {
  --rarity-color: #fff;

  background: linear-gradient(
    135deg,
    rgba(255, 255, 255, 0.06),
    rgba(255, 255, 255, 0.02)
  );
  border: 2px solid var(--rarity-color);
  border-radius: 12px;

  display: flex;
  align-items: center;
  gap: 12px;

  padding: 12px;
  position: relative;

  box-shadow: 0 0 12px var(--rarity-color);
  backdrop-filter: blur(4px);

  transition: transform 0.25s ease, box-shadow 0.25s ease;
}

.inventory-item:hover {
  transform: translateY(-4px) scale(1.02);
  box-shadow: 0 0 18px var(--rarity-color);
}

/* ICON WRAPPER */
.icon-wrapper {
  width: 48px;
  height: 48px;

  display: flex;
  align-items: center;
  justify-content: center;

  background: rgba(255, 255, 255, 0.07);
  border-radius: 10px;
  border: 1px solid rgba(255, 255, 255, 0.1);
}

.inventory-icon {
  width: 36px;
  height: 36px;
}

/* TEXT AREA */
.inventory-info {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.inventory-name {
  font-weight: 700;
  font-size: 1.05rem;
  letter-spacing: 0.5px;
  color: var(--rarity-color);
}

/* RARITY CHIP */
.rarity-tag {
  font-size: 0.8rem;
  font-weight: bold;
  padding: 2px 8px;
  width: fit-content;

  display: flex;
  align-items: center;
  gap: 6px;

  background: var(--rarity-color);
  color: #000;

  border-radius: 6px;
  box-shadow: 0 0 6px var(--rarity-color);
}

/* AMOUNT */
.inventory-amount {
  opacity: 0.85;
  font-size: 0.9rem;
}

.badge {
  position: absolute;
  top: 4px;
  right: 8px;
  padding: 3px 8px;
  font-size: 0.75rem;
  font-weight: bold;
  border-radius: 6px;
  backdrop-filter: blur(4px);
  z-index: 10;
}

/* Equipped badge */
.equipped-badge {
  background: rgba(80, 220, 120, 0.25);
  border: 1px solid rgba(80, 220, 120, 0.5);
  color: #4cff8a;
  box-shadow: 0 0 6px rgba(80, 220, 120, 0.5);
}

/* Locked badge */
.locked-badge {
  background: rgba(255, 80, 80, 0.25);
  border: 1px solid rgba(255, 80, 80, 0.5);
  color: #ff7070;
  box-shadow: 0 0 6px rgba(255, 80, 80, 0.5);
}

/* Locked item styling */
.inventory-item.locked {
  opacity: 0.6;
  filter: grayscale(80%);
}

/* Highlight equipped item */
.inventory-item.equipped {
  box-shadow: 0 0 16px rgba(80, 220, 120, 0.7) !important;
  border-color: #4cff8a !important;
}

.name-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

/* Main item name */
.inventory-name {
  font-weight: 700;
  font-size: 1rem;
  color: var(--rarity-color);
  margin-right: 8px;
}

/* BADGES */
.badge {
  padding: 2px 8px;
  font-size: 0.7rem;
  font-weight: bold;
  border-radius: 6px;
  backdrop-filter: blur(4px);
  display: inline-flex;
  align-items: center;
  animation: fadeIn 0.2s ease-out;
}

/* Equipped badge style */
.equipped-badge {
  background: rgba(80, 220, 120, 0.12);
  border: 1px solid rgba(80, 220, 120, 0.35);
  color: #35ff87;
  box-shadow: 0 0 6px rgba(80, 220, 120, 0.25);
}

/* Locked badge style */
.locked-badge {
  background: rgba(255, 80, 80, 0.12);
  border: 1px solid rgba(255, 80, 80, 0.35);
  color: #ff7676;
  box-shadow: 0 0 6px rgba(255, 80, 80, 0.25);
}

/* Optional fade-in animation */
@keyframes fadeIn {
  from { opacity: 0; transform: translateY(-2px); }
  to { opacity: 1; transform: translateY(0); }
}
</style>
