<template>
  <div class="card shadow text-light mt-4">
    <div class="card-body">
      <h4 class="card-title mb-3">Inventory</h4>

      <!-- FILTERS & SORT -->
      <div class="d-flex gap-3 mb-3 flex-wrap">
        <!-- TYPE FILTER -->
        <select v-model="selectedType" class="form-select w-auto">
          <option value="all">All Types</option>
          <option v-for="t in itemTypes" :key="t" :value="t">
            {{ t }}
          </option>
        </select>

        <!-- SORTING -->
        <select v-model="sortBy" class="form-select w-auto">
          <option value="name">Name (A–Z)</option>
          <option value="rarity">Rarity</option>
          <option value="amount">Amount</option>
        </select>
      </div>

      <!-- INVENTORY GRID -->
      <div class="inventory-grid">
        <InventoryItem
          v-for="item in sortedAndFiltered"
          :key="item.itemKey"
          :item="item"
        />
      </div>
    </div>
  </div>
</template>

<script setup>
import InventoryItem from "./InventoryItem.vue";
import { ref, computed } from "vue";
import { getGame } from "../game/state/gameState";
import { getItem } from "../game/utils/itemDB";

const game = getGame();

const sortBy = ref("name");
const selectedType = ref("all");

/* Alle item types genereren vanuit DB */
const itemTypes = ["resources", "tools"];

/* RAW inventory items */
const rawItems = computed(() => {
  return Object.entries(game.inventory)
    .map(([itemKey, amount]) => {
      const base = getItem(itemKey);

      if (!base) {
        console.warn("Unknown inventory item:", itemKey);
        return null;
      }

      return {
        ...base, // itemDB data (id, name, icon, rarity, etc.)
        itemKey, // inventory key
        amount,
      };
    })
    .filter(Boolean);
});

/* FILTER → SORT → RESULT */
const sortedAndFiltered = computed(() => {
  let list = [...rawItems.value];

  // FILTER
  if (selectedType.value !== "all") {
    list = list.filter((i) => i.category === selectedType.value);
  }

  // SORT
  list.sort((a, b) => {
    switch (sortBy.value) {
      case "rarity":
        return (b.rarity || 0) - (a.rarity || 0);
      case "amount":
        return b.amount - a.amount;
      default:
        return a.name.localeCompare(b.name);
    }
  });

  return list;
});
</script>

<style scoped>
.inventory-grid {
  display: grid;
  gap: 12px;
  grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
}
</style>
