<template>
  <div
    :class="['card', 'shadow', 'text-light', 'skill-card', 'skill-' + skillKey]"
  >
    <div class="card-body">
      <!-- SKILL TITLE -->
      <h4 class="card-title d-flex align-items-center gap-2">
        <span class="skill-icon-svg" v-html="skill.iconSvg"></span>
        {{ skill.name }}
      </h4>

      <!-- LEVEL -->
      <p><strong>Level:</strong> {{ skill.level }}</p>

      <!-- XP BAR -->
      <div class="xp-wrapper mb-2">
        <div class="d-flex justify-content-between small mb-1">
          <span>XP</span>
          <span>{{ skill.xp }} / {{ skill.xpToNext }}</span>
        </div>

        <div class="xp-bar">
          <div class="xp-fill" :style="{ width: xpPercent + '%' }"></div>
        </div>
      </div>

      <!-- LEVEL-UP POPUP -->
      <div v-if="skill.justLeveled" class="levelup-popup">
        ✨ Level {{ skill.level }}!
      </div>

      <!-- IDLE SKILL ACTION BUTTON -->
      <router-link
        v-if="skill"
        class="btn btn-primary w-100 mt-3 text-center"
        :to="`/skills/${skillKey}`"
      >
        View Skill
      </router-link>
    </div>
  </div>
</template>

<script setup>
import { computed } from "vue";

const props = defineProps({
  skill: Object,
  skillKey: String,
  inventory: Object,
});

const xpPercent = computed(() =>
  Math.min((props.skill.xp / props.skill.xpToNext) * 100, 100)
);
</script>

<style scoped>
.skill-icon-svg {
  width: 32px;
  height: 32px;
  display: inline-flex;
}

.xp-bar {
  height: 8px;
  background: rgba(255, 255, 255, 0.15);
  border-radius: 4px;
  overflow: hidden;
}

.xp-fill {
  height: 100%;
  background: linear-gradient(90deg, #4caf50, #8bc34a);
}

.levelup-popup {
  text-align: center;
  background: rgba(255, 255, 0, 0.15);
  padding: 6px 10px;
  border-radius: 8px;
  margin-top: 10px;
  font-weight: bold;
  animation: pop 0.6s ease-out;
}

@keyframes pop {
  0% {
    transform: scale(0.5);
    opacity: 0;
  }
  100% {
    transform: scale(1);
    opacity: 1;
  }
}
</style>
