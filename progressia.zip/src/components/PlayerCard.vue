<template>
  <div class="card shadow text-light mb-4">
    <div class="card-body">
      <h4 class="card-title">Speler</h4>
      <p><strong>Naam:</strong> {{ player.name }}</p>
    </div>
  </div>
</template>

<script setup>
defineProps({
  player: Object
});
</script>
