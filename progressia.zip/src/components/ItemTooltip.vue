<template>
  <div
    v-if="tooltip.visible"
    class="tooltip-box"
    :style="{ top: tooltip.y + 'px', left: tooltip.x + 'px', borderColor: rarityColor }"
  >
    <!-- Title -->
    <div class="tooltip-title" :style="{ color: rarityColor }">
      {{ tooltip.item.name }}
    </div>

    <!-- Rarity -->
    <div class="tooltip-rarity" :style="{ color: rarityColor }">
      {{ rarityLabel }}
    </div>

    <!-- Description -->
    <p class="tooltip-desc">{{ tooltip.item.description }}</p>

    <!-- Type -->
    <div class="tooltip-type">
      <span class="label">Type:</span> {{ tooltip.item.category }}
    </div>

    <!-- TOOL STATS -->
    <div v-if="isTool" class="tool-stats-box mt-2">
      <div class="tool-stats-row">
        <span class="stat-label">Skill</span>
        <span class="stat-value">{{ tooltip.item.skill }}</span>
      </div>

      <div class="tool-stats-row">
        <span class="stat-label">Required Level</span>
        <span class="stat-value">{{ tooltip.item.stats.requiredLevel }}</span>
      </div>

      <div class="tool-stats-row">
        <span class="stat-label">XP Multiplier</span>
        <span class="stat-value">{{ tooltip.item.stats.xpMultiplier }}×</span>
      </div>

      <div class="tool-stats-row">
        <span class="stat-label">Speed Multiplier</span>
        <span class="stat-value">{{ tooltip.item.stats.speedMultiplier }}×</span>
      </div>

      <div class="tool-stats-row">
        <span class="stat-label">Double Chance</span>
        <span class="stat-value">{{ tooltip.item.stats.doubleChance }}%</span>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed } from "vue";
import { useTooltip } from "../composables/useTooltip";
import { getRarityColor, getRarityLabel } from "../game/utils/rarity";

const { tooltip } = useTooltip();

const rarityColor = computed(() =>
  getRarityColor(tooltip.value.item?.rarity)
);

const rarityLabel = computed(() =>
  getRarityLabel(tooltip.value.item?.rarity)
);

// Als item.category === "tools"
const isTool = computed(() => tooltip.value.item?.category === "tools");
</script>

<style scoped>
.tooltip-box {
  position: fixed;
  z-index: 99999;

  background: #1118;
  padding: 14px 18px;

  border: 2px solid;
  border-radius: 12px;

  min-width: 300px;

  backdrop-filter: blur(8px);
  color: #fff;

  animation: fadeIn 0.15s ease-out;
  pointer-events: none;

  box-shadow: 0 8px 18px #0008;
}

.tooltip-title {
  font-size: 1.2rem;
  font-weight: 700;
}

.tooltip-rarity {
  font-size: 0.9rem;
  opacity: 0.8;
  margin-bottom: 8px;
}

.tooltip-desc {
  margin: 8px 0;
  opacity: 0.9;
  line-height: 1.35;
}

.tooltip-type {
  font-size: 0.85rem;
  opacity: 0.8;
  margin-top: 8px;
}

.label {
  font-weight: 600;
  color: #ffd27d;
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(5px);
  }
  to {
    opacity: 1;
  }
}

/* ✨ TOOL STATS BOX */
.tool-stats-box {
  margin-top: 12px;
  background: #ffffff10;
  padding: 10px;
  border-radius: 10px;
  border: 1px solid #ffffff22;
}

.tool-stats-row {
  display: flex;
  align-items: center;
  margin-bottom: 4px;
}

.tool-stats-row:last-child {
  margin-bottom: 0;
}

.stat-label {
  flex: 1;
  font-size: 0.85rem;
  opacity: 0.85;
}

.stat-value {
  font-weight: 600;
  color: #ffd27d;
}
</style>
