<template>
  <div class="notification-container">
    <div v-for="n in notifications" :key="n.id" class="notification">
      {{ n.message }}
    </div>
  </div>
</template>

<script setup>
import { useNotifications } from '../composables/useNotification';

const { notifications } = useNotifications();
</script>

<style scoped>
.notification-container {
  position: fixed;
  top: 20px;
  right: 20px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  z-index: 9999;
}

.notification {
  background: rgba(0,0,0,0.75);
  color: #fff;
  padding: 10px 14px;
  border-radius: 10px;
  font-weight: bold;
  animation: slide-in 0.3s ease, fade-out 0.5s ease 1.8s forwards;
  box-shadow: 0 4px 10px rgba(0,0,0,0.25);
}

/* Animaties */
@keyframes slide-in {
  from { opacity: 0; transform: translateX(40px); }
  to   { opacity: 1; transform: translateX(0); }
}

@keyframes fade-out {
  to { opacity: 0; transform: translateX(40px); }
}
</style>
