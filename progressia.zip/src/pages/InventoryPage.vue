<template>
  <div class="card shadow text-light">
    <div class="card-body">
      <h3 class="mb-3">🎒 Inventory</h3>

      <InventoryGrid :items="inventoryList" />
    </div>
  </div>
</template>

<script setup>
import InventoryGrid from "../components/InventoryGrid.vue";
import { computed } from "vue";
import { getGame } from "../game/state/gameState";

// ⬇️ Nieuwe import van de dynamic item DB
import { getItem } from "../game/utils/itemDB";

const game = getGame();

/**
 * Bouw inventory lijst:
 * - key = item ID
 * - amount = hoeveelheid in inventory
 * - ...properties uit dynamic itemLoader
 */
const inventoryList = computed(() =>
  Object.entries(game.inventory).map(([itemKey, amount]) => {
    const base = getItem(itemKey); // dynamische data

    if (!base) {
      console.warn("Unknown item:", itemKey);
      return null;
    }

    return {
      ...base,
      itemKey, // <-- DE INVENTORY KEY
      amount,
    };
  }).filter(Boolean)
);
</script>
