<template>
  <div class="card shadow text-light">
    <div class="card-body">
      <h3 class="mb-3">🧍 Player Info</h3>

      <p><strong>Name:</strong> {{ game.player.name }}</p>

      <h5 class="mt-4">Skill Levels</h5>
      <ul class="list-group">
        <li
          v-for="(skill, key) in game.skills"
          :key="key"
          class="list-group-item bg-dark text-light d-flex justify-content-between"
        >
          {{ skill.name }}
          <span>Lvl {{ skill.level }}</span>
        </li>
      </ul>
    </div>
  </div>
</template>

<script setup>
import { getGame } from "../game/state/gameState";

const game = getGame();
</script>
