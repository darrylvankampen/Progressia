<template>
  <div class="skill-detail container py-4" v-if="ready && skill && data">
    <!-- MAIN SKILL CARD (exact same styling as list card, but wider) -->
    <div class="card shadow text-light skill-card mb-4 p-3">
      <div class="card-body">
        <!-- HEADER -->
        <h3 class="card-title d-flex align-items-center gap-2 mb-3">
          <span class="skill-icon-svg" v-html="data.iconSvg"></span>
          {{ data.name }}
        </h3>

        <!-- LEVEL -->
        <p>
          <strong>Level:</strong> {{ skill.level
          }}<span v-if="skill.level === skill.maxLevel" class="max-badge">
            MAX
          </span>
        </p>

        <!-- XP BAR -->
        <div class="xp-wrapper mb-2">
          <div class="d-flex justify-content-between small mb-1">
            <span>XP</span>
            <span>{{ skill.xp }} / {{ skill.xpToNext }}</span>
          </div>

          <div class="xp-bar">
            <div class="xp-fill" :style="{ width: xpPercent + '%' }"></div>
          </div>
        </div>

        <!-- LEVEL-UP POPUP -->
        <div v-if="skill.justLeveled" class="levelup-popup">
          ✨ Level {{ skill.level }}!
        </div>
      </div>
    </div>

    <!-- ACTIVE ACTION BOX -->
    <div
      v-if="skill.isActive && skill.currentAction"
      class="active-box card shadow-sm text-light p-3 mb-4"
    >
      <div class="d-flex justify-content-between align-items-center">
        <div>
          <strong>{{ skill.currentAction.name }}</strong>
          <div class="small text-muted">Currently working...</div>
        </div>

        <div class="d-flex align-items-center gap-3">
          <span class="timer">{{ formattedTimeLeft }}</span>
          <button
            class="btn btn-danger btn-sm"
            @click="toggleAction(skill.currentAction)"
          >
            Stop
          </button>
        </div>
      </div>
      <!-- PROGRESS BAR -->
      <div class="action-progress-wrapper mt-2">
        <div class="action-progress">
          <div
            class="action-progress-fill"
            :style="{ width: actionProgress + '%' }"
          ></div>
        </div>
      </div>
    </div>

    <!-- EQUIPPED TOOL -->
    <div
      v-if="equippedTool"
      class="card shadow-sm text-light p-3 mb-4 equipped-tool-box"
    >
      <div class="d-flex align-items-center gap-3">
        <img :src="equippedTool.icon" class="tool-icon" />

        <div>
          <strong>Equipped Tool:</strong><br />
          {{ equippedTool.name }}

          <div class="small mt-1">
            Speed: ×{{ equippedTool.stats.speedMultiplier }} • XP: ×{{
              equippedTool.stats.xpMultiplier
            }}
            • Double Chance:
            {{ Math.round(equippedTool.stats.doubleChance * 100) }}%
          </div>
        </div>
      </div>
    </div>

    <!-- ACTIONS GRID -->
    <div class="row g-4">
      <div
        v-for="action in unlockedActions"
        :key="action.id"
        class="col-sm-6 col-md-4 col-lg-3"
      >
        <div class="card shadow text-light action-card p-3">
          <div class="card-body d-flex flex-column">
            <h5 class="card-title mb-2">{{ action.name }}</h5>

            <p class="small text-muted mb-3">
              <strong>XP:</strong> {{ action.xpGain }} <br />
              <strong>Time:</strong> {{ action.actionTime / 1000 }}s <br />
              <strong>Resource:</strong> {{ getItemName(action.resource) }}
            </p>

            <button
              class="btn btn-primary w-100 mt-auto"
              @click="toggleAction(action)"
            >
              <span
                v-if="skill.isActive && skill.currentAction?.id === action.id"
              >
                Stop
              </span>
              <span v-else>Start</span>
            </button>
          </div>
        </div>
      </div>

      <div v-if="unlockedActions.length === 0" class="col-12">
        <div class="alert alert-warning text-center">
          No actions unlocked yet.
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from "vue";
import {
  getGame,
  gameReady,
  getSkillDefs,
  skillDefsReady,
} from "../../game/state/gameState";
import { startAction, stopSkill } from "../../game/skillEngine";
import { formatTime } from "../../game/utils/formatTime";
import {
  getSkillConfig,
  getItemName,
  getEquippedTool,
} from "../../game/helpers/gameHelpers";

// -----------------------------------------------------
// WAIT UNTIL GAME IS LOADED
// -----------------------------------------------------
const ready = ref(false);

gameReady
  .then(() => skillDefsReady)
  .then(() => {
    ready.value = true;
  });

// -----------------------------------------------------
// REACTIVE SKILL ACCESS
// -----------------------------------------------------
const game = getGame();

// Player progress
const skill = computed(() => game.skills?.woodcutting || null);

// Skill config (met actions, iconSvg, naam)
const data = computed(() => getSkillConfig("woodcutting"));

const equippedTool = computed(() => {
  console.log(getEquippedTool("woodcutting"));
  return getEquippedTool("woodcutting");
});
// -----------------------------------------------------
// XP-PERCENTAGE
// -----------------------------------------------------
const xpPercent = computed(() => {
  if (!skill.value) return 0;
  return Math.min(100, (skill.value.xp / skill.value.xpToNext) * 100);
});

// -----------------------------------------------------
// UNLOCKED ACTIONS
// -----------------------------------------------------
const unlockedActions = computed(() => {
  if (!data.value || !skill.value) return [];
  return data.value.actions.filter((a) => a.requiredLevel <= skill.value.level);
});

// -----------------------------------------------------
// TIMER
// -----------------------------------------------------
const formattedTimeLeft = computed(() => {
  if (!skill.value?.currentAction) return "";
  return formatTime(skill.value.currentAction.timeLeft);
});

const actionProgress = computed(() => {
  if (!skill.value?.currentAction) return 0;

  const total = skill.value.currentAction.actionTime;
  const left = skill.value.currentAction.timeLeft;

  return Math.min(100, ((total - left) / total) * 100);
});

// -----------------------------------------------------
// START ACTION
// -----------------------------------------------------
function toggleAction(action) {
  // Als deze actie actief is → stop hem
  if (skill.value.isActive && skill.value.currentAction?.id === action.id) {
    stopSkill("woodcutting");
    return;
  }

  // Start nieuwe actie
  startAction("woodcutting", action);
}
</script>

<style scoped>
.skill-icon-svg {
  width: 40px;
  height: 40px;
  display: inline-flex;
}

.skill-card,
.action-card,
.active-box {
  background: rgba(255, 255, 255, 0.08);
  border-radius: 12px;
  backdrop-filter: blur(10px);
}

.xp-bar {
  height: 8px;
  background: rgba(255, 255, 255, 0.15);
  border-radius: 4px;
  overflow: hidden;
}

.xp-fill {
  height: 100%;
  background: linear-gradient(90deg, #4caf50, #8bc34a);
  transition: width 0.3s ease-in-out;
}

.levelup-popup {
  text-align: center;
  background: rgba(255, 255, 0, 0.15);
  padding: 6px 10px;
  border-radius: 8px;
  margin-top: 10px;
  font-weight: bold;
  animation: pop 0.6s ease-out;
}

@keyframes pop {
  0% {
    transform: scale(0.5);
    opacity: 0;
  }
  100% {
    transform: scale(1);
    opacity: 1;
  }
}

.action-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
  transition: 0.2s ease;
}

.timer {
  font-weight: bold;
  font-size: 1.15rem;
  letter-spacing: 1px;
}

.action-progress {
  height: 8px;
  background: rgba(255, 255, 255, 0.15);
  border-radius: 4px;
  overflow: hidden;
}

.action-progress-fill {
  height: 100%;
  background: linear-gradient(90deg, #4fa3ff, #589bff);
  transition: width 0.1s linear;
}

.tool-icon {
  width: 40px;
  height: 40px;
  border-radius: 6px;
  background: rgba(255, 255, 255, 0.1);
  padding: 4px;
}
.equipped-tool-box {
  background: rgba(255, 255, 255, 0.08);
  border-radius: 12px;
}

.max-badge {
  display: inline-block;
  padding: 4px 8px;
  margin-left: 10px;
  font-size: 0.8rem;
  font-weight: bold;
  border-radius: 6px;

  background: rgba(255, 215, 0, 0.25); /* goudkleurige glow */
  border: 1px solid rgba(255, 215, 0, 0.4);
  color: #ffd700;

  backdrop-filter: blur(4px);
  animation: pulse 2s infinite;
}

@keyframes pulse {
  0%   { transform: scale(1); opacity: 1; }
  50%  { transform: scale(1.1); opacity: 0.8; }
  100% { transform: scale(1); opacity: 1; }
}
</style>
