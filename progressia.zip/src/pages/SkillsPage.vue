<template>
  <SkillGrid
    :skills="sortedSkills"
    :inventory="game.inventory"
    @open-skill="$emit('open-skill', $event)"
  />
</template>

<script setup>
import { computed } from "vue";
import SkillGrid from "../components/SkillGrid.vue";
import { getGame } from "../game/state/gameState";

const game = getGame();

const sortedSkills = computed(() =>
  Object.entries(game.skills)
    .sort((a, b) => {
      if (a[1].isIdle && !b[1].isIdle) return -1;
      if (!a[1].isIdle && b[1].isIdle) return 1;
      return a[1].name.localeCompare(b[1].name);
    })
    .map(([key, value]) => ({ key, ...value }))
);
</script>
