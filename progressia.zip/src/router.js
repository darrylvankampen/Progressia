import { createRouter, createWebHashHistory } from "vue-router";

import PlayerPage from "./pages/PlayerPage.vue";
import SkillsPage from "./pages/SkillsPage.vue";
import InventoryPage from "./pages/InventoryPage.vue";
import CraftingPage from "./pages/CraftingPage.vue";
import ShopPage from "./pages/ShopPage.vue";
import SettingsPage from "./pages/SettingsPage.vue";

import WoodcuttingPage from "./pages/skills/WoodcuttingPage.vue";
// later: import MiningPage, FishingPage, etc.

const routes = [
  { path: "/", redirect: "/player" },

  { path: "/player", component: PlayerPage },
  { path: "/skills", component: SkillsPage },
  { path: "/inventory", component: InventoryPage },
  { path: "/skills/crafting", component: CraftingPage },
  { path: "/shop", component: ShopPage },
  { path: "/settings", component: SettingsPage },

  // ⭐ Skill detail pages
  { path: "/skills/woodcutting", component: WoodcuttingPage },
];

export const router = createRouter({
  history: createWebHashHistory(),
  routes
});
